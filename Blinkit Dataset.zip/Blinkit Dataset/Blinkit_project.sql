-- Blinkit_Project

-- Show all products

use blinkit;
select * 
from blinkit_products ;

-- Display product names and prices

select product_name , price 
from blinkit_products;

-- Find all orders

select * 
from blinkit_orders;

-- Show customers from a specific area

select customer_name 
from blinkit_customers 
where area  in ('pune'); 

select customer_name 
from blinkit_customers 
where area = 'pune'; 

-- List products with price > 100

select *
from blinkit_products
where price > 100 ;

-- Find orders with total > 500

select * 
from blinkit_orders 
where order_total > 500 ;

-- Sort products by price ascending

select * 
from blinkit_products 
order by price ;

-- Sort customers by registration date

select * 
from blinkit_customers
order by registration_date desc;

-- Show top 5 expensive products

select * 
from blinkit_products 
order by price desc
limit 5;

-- Find unique product categories

select distinct category
from blinkit_products;

-- Filter products by category = 'Dairy'

select *
from blinkit_products 
where category = 'dairy';

-- Find customers with more than 5 orders

select * 
from blinkit_customers 
where total_orders > 5;

-- Show orders after '2024-01-01'

select *
from blinkit_orders 
where order_date > '2024-01-01';

-- Display products with margin > 20%

select * 
from blinkit_products 
where margin_percentage > '20%' ;

-- List products with MRP > price

select * 
from blinkit_products 
where mrp > price ;

-- Find orders with payment method 'cash'

select payment_method 
from blinkit_orders;

select * 
from blinkit_orders 
where payment_method = 'cash';

-- Get all delayed deliveries

select delivery_status 
from blinkit_delivery_performance;

select *
from blinkit_delivery_performance 
where delivery_status in ('slightly delayed' , 'significantly delayed');

select *
from blinkit_delivery_performance
where delivery_status like '%delayed%';

SELECT *
FROM blinkit_delivery_performance
WHERE delivery_status = 'slightly delayed'
   OR delivery_status = 'significantly delayed';

select *
from blinkit_delivery_performance
where delivery_status like '%delayed%';

select * 
from blinkit_delivery_performance 
where delivery_status = 'slightly delayed'
OR delivery_status = 'significantly delayed';

-- Show products with low stock

SELECT product_name , min_stock_level
FROM blinkit_products ;

-- Find customers with avg order > 300


select customer_name , avg(total_orders) as total
from blinkit_customers 
group by customer_name
having total > 9;

select *
from blinkit_customers;

select  *
from blinkit_customers
where avg_order_value > 300 ;

-- Display inventory records

select count(*)
from blinkit_inventory;

-- Count total products

select count(*)
from blinkit_products ;

-- Count total customers 

select count(*)
from blinkit_customers;

-- Count total orders

select count(*)
from blinkit_orders;

-- Find max product price

select max(price)
from blinkit_products;

-- Find min product price

select min(price)
from blinkit_products;

-- Calculate average order value

select sum(avg_order_value)
from blinkit_customers;

-- Show distinct delivery statuses

select distinct delivery_status 
from blinkit_orders;

-- List all brands

select brand 
from blinkit_products;

-- Count orders per status

select delivery_status , count(*)
from blinkit_orders
group by delivery_status;

-- Show all campaign names

select campaign_name 
from blinkit_marketing_performance;

-- Filter campaigns with spend > 1000

select * 
from blinkit_marketing_performance 
where spend > 1000
order by spend desc;

-- Show campaigns with conversions > 50

select campaign_id , conversions
from blinkit_marketing_performance 
where conversions > 50;

-- Display customers from pincode 411001

select *
from blinkit_customers 
where pincode = 411001;

-- Show products sorted by margin

select *
from blinkit_products 
order by margin_percentage desc ;

-- Find orders with delivery delay
select * 
from blinkit_delivery_performance;

select * 
from blinkit_delivery_performance
where delivery_status = 'slightly delayed';

select * 
from blinkit_orders;

select *
from blinkit_orders 
where delivery_status in ( 'slightly delayed' , 'significantly delayed');



-- Show items with quantity > 3

-- Find orders with high value

-- Aggregation + GROUP BY:

-- Count products per category

SELECT category,
       COUNT(*) AS total_products
FROM blinkit_products
GROUP BY category;

select category , count(product_name)
from blinkit_products
group by category;

-- Average price per category

select category , avg(price)
from blinkit_products
group by category;

-- Total revenue per product

select product_id , sum( quantity * unit_price ) as  revenue
from blinkit_order_items
group by product_id;

-- Total orders per customer

select customer_name , sum(total_orders)
from blinkit_customers
group by customer_name;

-- Count orders per delivery status

select delivery_status , count(*)
from blinkit_orders
group by delivery_status ;

-- Average order value per customer

select customer_name , avg_order_value
from blinkit_customers;



-- Total spend per campaign
-- Total clicks per channel
-- Conversion rate per campaign
-- Revenue per campaign

-- JOIN Questions :


-- Join orders with customers

select *
from blinkit_orders o
join blinkit_customers c
on bo.customer_id = bc.customer_id;

-- Show customer name with order total

use blinkit;

select customer_name , total_orders
from blinkit_customers;

select c.customer_name , o.order_total 
from blinkit_customers c 
join blinkit_orders o 
on c.customer_id = o.customer_id ;

-- Join order items with products

select * 
from blinkit_order_items  oi 
join blinkit_products p 
on oi.product_id = p.product_id;

-- Show product name with quantity sold

select p.product_name , sum(oi.quantity * oi.unit_price) as quantity_sold
from blinkit_order_items oi 
join blinkit_products p 
on oi.product_id = p.product_id 
group by product_name;

-- Join orders with delivery performance

select *
from blinkit_orders o 
join blinkit_delivery_performance a 
on o.order_id = a.order_id ;

-- Show delivery time per order

select o.actual_delivery_time , a.order_id 
from blinkit_orders o 
join blinkit_delivery_performance a 
on a.order_id = o.order_id;

select actual_delivery_time , order_id 
from blinkit_orders ; 

-- Join inventory with products

select * 
from blinkit_inventory i 
join blinkit_products p 
on i.product_id = p.product_id ;

-- Show stock per product

select p.product_name , i.stock_received 
from blinkit_products p 
join blinkit_inventory i 
on p.product_id = i.product_id;

-- Join campaigns with revenue



-- Show ROAS per campaign



-- Top 5 customers by spending
-- Top 5 selling products
-- Least selling products
-- Most used payment method
-- Most active customer segment
-- Products never ordered
-- Customers with no orders
-- Orders with multiple products
-- Average delivery time per partner
-- Delayed deliveries count
-- Case-Based
-- Find highest revenue product
-- Find lowest margin products
-- Best performing campaign
-- Worst performing campaign
-- Find most delayed orders
-- Average delivery distance
-- Total damaged stock per product
-- Stock received per day
-- Orders per day
-- Revenue per day
-- 🔵 ADVANCED LEVEL (81–120)
-- Subqueries
-- Products priced above average
-- Customers spending above average
-- Orders greater than avg order
-- Find top category by revenue
-- Products with highest sales
-- Customers with max orders
-- Orders with max delivery time
-- Campaign with highest ROAS
-- Product with lowest stock
-- Customer with highest avg order
-- Window Functions
-- Rank products by price
-- Rank customers by spending
-- Dense rank products by sales
-- Running total of revenue
-- Cumulative orders per day
-- Row number per category
-- Lag delivery time comparison
-- Lead order comparison
-- Moving average of sales
-- Top 3 products per category
-- CTE (WITH Clause)
-- Calculate total revenue using CTE
-- Find top customers using CTE
-- Create temporary sales table
-- Find delayed orders using CTE
-- Combine multiple CTEs
-- Business Problems
-- Find repeat customers
-- Calculate customer retention
-- Identify churn customers
-- Best delivery partner
-- Worst delivery partner
-- Real Interview Style
-- Find revenue contribution %
-- Category contribution %
-- Find median order value
-- Detect outliers in pricing
-- Find seasonal trends
-- Detect high return products
-- Identify slow-moving inventory
-- Find peak order hours
-- Calculate delivery efficiency
-- Optimize stock levels
-- Advanced JOIN (121–160)
-- Join orders, customers, and delivery tables to show full order details
-- Show customer name, product name, and quantity in one query
-- Find total revenue per customer with product details
-- Show all orders with delivery delay status
-- Join products with inventory to show current stock
-- Show products where stock < min_stock_level
-- Find orders where product price > MRP
-- Join campaigns with revenue generated
-- Show ROAS (revenue/spend) per campaign
-- Find customers who ordered from multiple categories
-- Find orders containing more than 2 products
-- Show customers who bought the same product multiple times
-- Join delivery + orders to calculate delay difference
-- Show average delivery time per area
-- Find customers with highest number of delayed orders
-- Show product-wise total revenue
-- Join inventory + products to find damaged %
-- Find products never delivered successfully
-- Show orders with missing delivery partner
-- Find customers who used multiple payment methods
-- Find top delivery partner by successful deliveries
-- Show order count per store
-- Join orders + items + products for full invoice view
-- Find products with zero inventory
-- Show orders with mismatched totals
-- Find duplicate orders
-- Join campaigns + clicks + conversions
-- Show CTR (click-through rate)
-- Show conversion rate per channel
-- Find best performing channel
-- Find orders placed but not delivered
-- Show customers with incomplete profiles
-- Find product category with highest orders
-- Join inventory + orders for stock usage
-- Find overstock products
-- Show inventory turnover rate
-- Find products with high damage rate
-- Show orders per delivery partner per day
-- Find delayed deliveries by area
-- Join all tables for full business report
-- 🧠 CASE STATEMENTS (161–200)
-- Classify orders as High/Medium/Low value
-- Categorize delivery as Fast/Normal/Slow
-- Segment customers by spending
-- Label products as Expensive/Affordable
-- Categorize campaigns by performance
-- Identify risky customers (low frequency)
-- Classify inventory status (Low/Optimal/Overstock)
-- Tag delayed orders
-- Classify delivery distance
-- Categorize revenue levels
-- Segment customers by AOV
-- Classify products by margin %
-- Identify best/worst delivery partners
-- Categorize campaigns by ROAS
-- Segment areas by demand
-- Identify slow-moving products
-- Categorize customers by recency
-- Flag high-return customers
-- Classify orders by payment type
-- Tag premium customers
-- Categorize products by shelf life
-- Flag expiring products
-- Segment users by order frequency
-- Classify stock health
-- Categorize campaign engagement
-- Label delivery efficiency
-- Segment customers by location
-- Classify product popularity
-- Identify VIP customers
-- Categorize orders by size
-- Classify inventory loss
-- Tag low-performing campaigns
-- Segment customers by churn risk
-- Classify delivery partners by rating
-- Categorize seasonal demand
-- Identify bulk orders
-- Classify product demand
-- Segment customers by lifetime value
-- Tag inactive users
-- Categorize order trends
-- 🔍 NESTED QUERIES (201–250)
-- Find products priced above average
-- Customers spending above average
-- Orders greater than avg order
-- Product with max sales
-- Customer with highest orders
-- Find second highest revenue product
-- Find nth highest order value
-- Products with below average sales
-- Customers with below avg spending
-- Find median order value
-- Top category by revenue (subquery)
-- Find products with highest margin
-- Customers with max AOV
-- Find orders above 90th percentile
-- Products contributing top 10% revenue
-- Customers who never ordered again
-- Products never sold
-- Find orders without items
-- Customers with no recent orders
-- Products not in inventory
-- Find best performing campaign
-- Worst performing campaign
-- Find product with max stock
-- Find category with lowest sales
-- Customers with highest delay count
-- Orders with longest delivery time
-- Customers with max cancellations
-- Products with highest return rate
-- Find outliers in order value
-- Orders above daily average
-- Find repeat purchase products
-- Customers with consistent spending
-- Find high variance customers
-- Products with fluctuating demand
-- Find stable products
-- Find top 5% customers
-- Bottom 10% products
-- Orders above category avg
-- Customers above segment avg
-- Products above brand avg
-- Find anomalies in delivery time
-- Detect abnormal orders
-- Identify fraud patterns
-- Customers ordering unusually high
-- Products priced unusually high
-- Detect missing data patterns
-- Identify duplicates using subqueries
-- Find inconsistencies in totals
-- Detect pricing errors
-- Validate data integrity
-- 🔵 LEVEL 3 → ANALYTICS (251–400)

-- (Window Functions + Advanced Analytics)

-- 🪟 Window Functions (251–320)
-- Rank products by price
-- Rank customers by spending
-- Dense rank products by sales
-- Row number per category
-- Top 3 products per category
-- Running total of revenue
-- Running total per customer
-- Cumulative orders per day
-- Rolling average revenue
-- Moving avg of last 7 days
-- Lag order value
-- Lead order comparison
-- Compare current vs previous order
-- Detect growth trends
-- Identify drop in sales
-- Rank delivery partners by performance
-- Rank campaigns by ROI
-- Rank customers by frequency
-- Rank categories by revenue
-- Rank brands by popularity
-- Percentile rank of orders
-- Divide customers into quartiles
-- Top 10% customers
-- Bottom 20% products
-- Revenue contribution %
-- Window avg per category
-- Window sum per brand
-- Max per partition
-- Min per partition
-- Count per partition
-- Find first order per customer
-- Find last order per customer
-- Time difference between orders
-- Identify repeat purchases
-- Detect churn patterns
-- Compare delivery times across days
-- Rank delays by severity
-- Analyze peak hours
-- Find busiest day
-- Compare weekday vs weekend
-- Segment customers dynamically
-- Identify high growth customers
-- Detect declining customers
-- Find consistent buyers
-- Detect one-time buyers
-- Rank products by margin
-- Rank inventory usage
-- Identify stock trends
-- Detect stock-outs
-- Analyze supply patternsAdvanced Analytics (301–400)
-- Cohort analysis (monthly users)
-- Retention analysis
-- Churn rate calculation
-- Customer lifetime value trend
-- Revenue growth rate
-- Month-over-month growth
-- Year-over-year growth
-- Seasonal trend analysis
-- Peak sales period
-- Low sales period
-- Customer segmentation (RFM)
-- Frequency distribution
-- Revenue distribution
-- Order size distribution
-- Category performance
-- Campaign ROI analysis
-- Channel effectiveness
-- Conversion funnel
-- Drop-off analysis
-- Attribution modeling
-- Delivery efficiency score
-- Partner performance score
-- Delay impact on revenue
-- Distance vs time regression
-- Predict delay patterns
-- Inventory turnover
-- Stock aging analysis
-- Dead stock detection
-- Overstock detection
-- Demand forecasting (basic SQL)
-- Product lifecycle analysis
-- Category growth rate
-- Brand performance trends
-- Price elasticity analysis
-- Discount impact
-- Customer behavior patterns
-- Basket analysis
-- Cross-selling opportunities
-- Upselling opportunities
-- Repeat purchase rate
-- Fraud detection patterns
-- Outlier detection
-- Data anomaly detection
-- Missing data analysis
-- Data consistency checks
-- Profitability analysis
-- Margin trends
-- Cost vs revenue
-- High-profit products
-- Low-profit products
-- Customer satisfaction proxy
-- Delivery impact on retention
-- Campaign impact on sales
-- Marketing efficiency
-- ROI optimization
-- Supply chain efficiency
-- Warehouse performance
-- Inventory wastage
-- Damage analysis
-- Stock optimization
-- Revenue forecasting
-- Demand spikes detection
-- Trend breaks
-- Growth acceleration
-- Decline detection
-- Category dominance
-- Market basket size
-- Order frequency trend
-- Customer growth trend
-- Product adoption rate
-- Regional performance
-- Area-wise demand
-- Delivery efficiency by region
-- Revenue by region
-- Customer density
-- Profit contribution %
-- Revenue contribution %
-- Top drivers of sales
-- Key loss drivers
-- Optimization opportunities
-- KPI dashboard queries
-- Executive summary metrics
-- Business health score
-- Growth indicators
-- Risk indicators
-- Campaign optimization
-- Budget allocation
-- ROI improvement
-- Target audience analysis
-- Channel optimization
-- Advanced cohort retention
-- Multi-level segmentation
-- Customer journey mapping
-- Funnel optimization
-- Predictive indicators
-- Performance benchmarking
-- Competitive analysis (simulated)
-- Scenario analysis
-- What-if analysis
-- Strategic insights
-- Business + Case-Based (401–450)
-- Find top 10% customers contributing to 80% revenue
-- Identify customers whose spending dropped month-over-month
-- Detect sudden drop in daily revenue
-- Find products causing revenue decline
-- Identify categories with negative growth
-- Find customers who churned after first order
-- Identify customers with increasing order frequency
-- Detect abnormal spike in orders
-- Find customers with irregular buying patterns
-- Identify seasonal products
-- Find products frequently bought together (basket analysis)
-- Identify cross-selling opportunities
-- Find most common product combinations
-- Detect substitution products
-- Find products with high cart abandonment (simulate)
-- Identify customers sensitive to price changes
-- Detect products affected by discounts
-- Find elasticity of demand
-- Identify products losing popularity
-- Find trending products
-- Find delivery delays impacting revenue
-- Identify worst performing regions
-- Detect delivery bottlenecks
-- Find peak delay hours
-- Identify partners causing delays
-- Find campaigns with high spend but low conversion
-- Detect inefficient marketing channels
-- Find campaigns driving repeat customers
-- Identify campaign saturation
-- Detect declining campaign performance
-- Find high-value customers at risk
-- Detect drop in customer retention
-- Identify inactive customers
-- Find customers returning after long gap
-- Identify loyal vs occasional users
-- Find products with high returns/damage
-- Detect inventory wastage patterns
-- Identify slow-moving stock
-- Find dead stock
-- Identify overstock risks
-- Identify top profit contributors
-- Detect low-margin high-volume products
-- Find loss-making products
-- Identify margin leakage
-- Detect pricing anomalies
-- Find top-performing stores
-- Detect underperforming stores
-- Identify store-level demand
-- Compare store performance
-- Find store growth trends
-- SQL Logic + Complex Queries (451–500)
-- Find second highest order value per customer
-- Find nth highest product price per category
-- Get top 3 orders per day
-- Find customers with consecutive purchase days
-- Detect gaps in order dates
-- Find running total of revenue per customer
-- Calculate cumulative revenue per category
-- Find moving average of last 5 orders
-- Identify trend reversal in sales
-- Detect anomalies using window functions
-- Find duplicate customers using email/phone
-- Deduplicate records keeping latest entry
-- Identify inconsistent pricing
-- Detect missing foreign keys
-- Validate referential integrity
-- Find orders with mismatch in total vs items sum
-- Detect incorrect discounts
-- Identify pricing errors
-- Validate revenue calculations
-- Detect corrupted data
-- Find customers ordering across multiple cities
-- Identify cross-region behavior
-- Detect migration of customers
-- Find region-switching patterns
-- Identify multi-location users
-- Find products sold in all categories (tricky join)
-- Identify universal customers (bought all categories)
-- Detect exclusive customers
-- Find products unique to one category
-- Identify category overlap
-- Find orders where all items are from same category
-- Detect mixed-category baskets
-- Find high diversity orders
-- Identify single-product orders
-- Detect bulk purchase patterns
-- Find time between consecutive orders
-- Identify average reorder time
-- Detect frequent buyers
-- Identify dormant users
-- Find lifecycle stage of customers
-- Compute customer lifetime value using window
-- Rank customers by CLV
-- Identify high-growth customers
-- Detect declining customers
-- Find consistent revenue contributors
-- Detect fraud-like patterns (unusual spikes)
-- Identify extreme outliers
-- Detect suspicious orders
-- Validate transaction consistency
-- Identify abnormal usage patterns
-- 🏆 Hard / FAANG-Level SQL (501–550)
-- Build full funnel (impression → click → conversion)
-- Calculate conversion drop at each stage
-- Build cohort retention table
-- Calculate rolling retention
-- Identify cohort decay rate
-- Calculate customer LTV over time
-- Build revenue cohort
-- Segment users by cohort behavior
-- Compare cohorts performance
-- Detect cohort anomalies
-- Build RFM segmentation fully in SQL
-- Rank customers by recency, frequency, monetary
-- Assign RFM scores
-- Identify VIP customers
-- Detect churn risk using RFM
-- Build recommendation logic (top products per user)
-- Suggest next best product
-- Find similar users (collaborative filtering logic)
-- Identify product affinity
-- Build recommendation candidates
-- Detect supply-demand mismatch
-- Identify stock-out impact on revenue
-- Build stock replenishment logic
-- Predict low stock alerts
-- Optimize inventory levels
-- Build delivery SLA compliance report
-- Calculate SLA breach %
-- Identify critical delays
-- Rank partners by SLA adherence
-- Predict delay likelihood
-- Build marketing attribution model (basic)
-- Assign revenue to channels
-- Multi-touch attribution (simplified)
-- Detect channel overlap
-- Optimize marketing spend
-- Build profitability dashboard
-- Calculate contribution margin
-- Identify profit drivers
-- Detect cost leakages
-- Optimize pricing strategy
-- Build business KPI summary table
-- Create executive dashboard query
-- Build data mart using SQL
-- Create reusable metrics layer
-- Optimize heavy queries
-- Write query for large-scale dataset optimization
-- Use indexing strategy
-- Reduce query cost
-- Improve execution plan
-- Production-level SQL design
-- Total revenue, orders, customers
-- Daily/weekly/monthly revenue
-- Top products & categories
-- Revenue contribution %
-- Growth rate calculation
-- Customer segmentation
-- Repeat vs new customers
-- Average order value trend
-- Revenue by region
-- KPI summary table
-- Build one query combining all metrics
-- Optimize query performance
-- Create reusable views
-- Prepare dashboard dataset
-- Final executive summary
-- 🚚 PROJECT 2 (566–580)
-- 📦 DELIVERY & OPERATIONS DASHBOARD
-- 🎯 Goal:

-- Optimize logistics

-- Tasks:
-- Avg delivery time
-- SLA compliance %
-- Delay distribution
-- Partner performance ranking
-- Distance vs time
-- Delay reasons analysis
-- Area-wise performance
-- Peak delay hours
-- Delivery efficiency score
-- Worst vs best partners
-- Build operations KPI table
-- Detect bottlenecks
-- Optimize delivery routes (SQL logic)
-- Create final dataset
-- Dashboard-ready output
-- 🛒 PROJECT 3 (581–590)
-- 🧑‍🤝‍🧑 CUSTOMER ANALYTICS DASHBOARD
-- 🎯 Goal:

-- Understand users

-- Tasks:
-- Customer lifetime value
-- RFM segmentation
-- Retention rate
-- Churn analysis
-- Repeat purchase rate
-- Customer cohorts
-- Behavior segmentation
-- High-value customers
-- Risk customers
-- Final dataset
-- 📢 PROJECT 4 (591–600)
-- 📣 MARKETING PERFORMANCE DASHBOARD
-- 🎯 Goal:

-- Measure campaigns
-- CTR, conversion rate
-- ROAS calculation
-- Campaign comparison
-- Channel performance
-- Funnel analysis
-- Attribution logic
-- Budget efficiency
-- Identify best campaigns
-- Create marketing dataset
-- Final dashboard query